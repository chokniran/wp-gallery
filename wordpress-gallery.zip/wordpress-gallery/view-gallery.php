<?php
  function viewGallery( $atts ) {
  	$atts = shortcode_atts( array(
		'category' => '',
		'count' => '',
		'orderby' => '',
		'order' => '',
		'type' => '',
		'imagesize' => '',
		'gab' => '',
		'columns' => '',
	), $atts );
    
    //get param gallery
    $category = $atts['category'];
    $count = $atts['count'];
    $orderby = $atts['orderby'];
    $order = $atts['order'];
    $type = $atts['type'];
    $imagesize = $atts['imagesize'];
    $columns = $atts['columns'];
    $gab = $atts['gab'];

    //call value Category
    $resultCategory = setValueDefaultCategory($category);

    //call value Count
    $resultCount = setValueDefaultCount($count);

    //call value Orderby
    $resultOrderby = setValueDefaultOrderby($orderby);

    //call value Order
    $resultOrder = setValueDefaultOrder($order);

    //call value Imagesize
    $resultImagesize = setValueDefaultImagesize($imagesize);

    //call value style
    $resultType = setValueDefaultType($type);

    //call value Gab
    $resultGab = setValueDefaultGab($gab);

    //call value Columns
    $resultColumns = setValueDefaultColumns($columns);

    
   //condition query
   if(!empty($resultCategory)){
     $args = array(
     'post_type' => 'photogallery',
     'tax_query' => array(
		array(
			'taxonomy' => 'gallery-category',
			'field'    => 'slug',
			'terms'    => $resultCategory,
		),
	),
    'posts_per_page' => $resultCount,
    'order' => $resultOrder,
    'orderby' => $resultOrderby,
   );
   }else{
   	$args = array(
     'post_type' => 'photogallery',
     'posts_per_page' => $resultCount,
     'order' => $resultOrder,
     'orderby' => $resultOrderby,
   );

   } 
   
   //query gallery
   $the_query = new WP_Query( $args );
	if ( $the_query->have_posts() ) {
		?>
		<link rel='stylesheet' href='<?php echo plugins_url( 'css/style.css' , __FILE__ )?>' type='text/css' media='all' />
		<?php 
        if($resultType == 'grid'){
        	//call style grid
            randerGrid($the_query, $resultGab, $resultColumns, $resultImagesize);
        }else{
            randerSlide($the_query,$resultGab, $resultColumns, $resultImagesize);
        }
		wp_reset_postdata();
	} else {}
	?>
	<?php
  }
add_shortcode( 'viewGallery', 'viewGallery' );


//set value Default of Gallery Category
function setValueDefaultCategory($args){
  if(!empty($args)){
    $category = explode(",", $args);
    if(!empty($category[1])){
       return $category;
    }else{
       return $args;
    }
  }else{
  	return '';
  }
}

//set value Default of Gallery Count
function setValueDefaultCount($args){
  if(!empty($args)){
    return $args;
  }else{
  	return 100;
  }
}

//set value Default of Gallery Orderby
function setValueDefaultOrderby($args){
  if(!empty($args)){
    return $args;
  }else{
  	return 'date';
  }
}
//set value Default of Gallery Order
function setValueDefaultOrder($args){
  if(!empty($args)){
    return $args;
  }else{
  	return 'DESC';
  }
}

//set value Default of Gallery Imagesize
function setValueDefaultImagesize($args){
  
  if(!empty($args)){
     return $args;
  }else{
  	 return 'style1';
  }
}

//set value Default of Gallery Gab
function setValueDefaultGab($args){
  
  if(!empty($args)){
     return $args;
  }else{
  	 return 0;
  }
}

//set value Default of Gallery Columns
function setValueDefaultColumns($columns){ 
  if(!empty($args)){
     return $args;
  }else{
  	 return 4;
  }
}

//set value Default of Gallery Imagesize
function setValueDefaultType($args){
  
  if(!empty($args)){
     return $args;
  }else{
  	 return 'grid';
  }
}

//add thumbnails gallery
add_image_size( 'style1', 600, 400, true ); 
add_image_size( 'style2', 600, 600, true ); 
add_theme_support('post-thumbnails');

//incloude script fancybox
function includeOwlcarousel(){
  ?>
   <script type="text/javascript" src="<?php echo plugins_url('js/owl.carousel.min.js' , __FILE__)?>"></script>
   <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('css/owl.carousel.css' , __FILE__)?>" media="screen" />
  <?php
}

//incloude script fontawesome
function includefontawesome(){
  ?>
   <link rel="stylesheet" type="text/css" href="<?php echo plugins_url('font-awesome-4.6.3/css/font-awesome.min.css' , __FILE__)?>" media="screen" />
  <?php
}

//incloude script fancybox
function includeFancybox(){
?>  
	<!-- Add mousewheel plugin (this is optional) -->
	<script type="text/javascript" src="<?php echo plugins_url('js/jquery.mousewheel-3.0.6.pack.js' , __FILE__)?>"></script>

	<!-- Add fancyBox main JS and CSS files -->
	<script type="text/javascript" src="<?php echo plugins_url('source/jquery.fancybox.js?v=2.1.5' , __FILE__)?>/"></script>
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('source/jquery.fancybox.css?v=2.1.5' , __FILE__)?>" media="screen" />

	<!-- Add Button helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('source/helpers/jquery.fancybox-buttons.css?v=1.0.5' , __FILE__)?>" />
	<script type="text/javascript" src="<?php echo plugins_url('source/helpers/jquery.fancybox-buttons.js?v=1.0.5' , __FILE__)?>"></script>

	<!-- Add Thumbnail helper (this is optional) -->
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url('source/helpers/jquery.fancybox-thumbs.css?v=1.0.7' , __FILE__)?>" />
	<script type="text/javascript" src="<?php echo plugins_url('source/helpers/jquery.fancybox-thumbs.js?v=1.0.7' , __FILE__)?>"></script>

	<!-- Add Media helper (this is optional) -->
	<script type="text/javascript" src="<?php echo plugins_url('source/helpers/jquery.fancybox-media.js?v=1.0.6' , __FILE__)?>"></script>

	<script type="text/javascript">
		jQuery(document).ready(function() {
			console.log('333');
			/*
			 *  Simple image gallery. Uses default settings
			 */

			jQuery('.fancybox').fancybox();

			/*
			 *  Different effects
			 */

			// Change title type, overlay closing speed
			jQuery(".fancybox-effects-a").fancybox({
				helpers: {
					title : {
						type : 'outside'
					},
					overlay : {
						speedOut : 0
					}
				}
			});

			// Disable opening and closing animations, change title type
			jQuery(".fancybox-effects-b").fancybox({
				openEffect  : 'none',
				closeEffect	: 'none',

				helpers : {
					title : {
						type : 'over'
					}
				}
			});

			// Set custom style, close if clicked, change title type and overlay color
			jQuery(".fancybox-effects-c").fancybox({
				wrapCSS    : 'fancybox-custom',
				closeClick : true,

				openEffect : 'none',

				helpers : {
					title : {
						type : 'inside'
					},
					overlay : {
						css : {
							'background' : 'rgba(238,238,238,0.85)'
						}
					}
				}
			});

			// Remove padding, set opening and closing animations, close if clicked and disable overlay
			jQuery(".fancybox-effects-d").fancybox({
				padding: 0,

				openEffect : 'elastic',
				openSpeed  : 150,

				closeEffect : 'elastic',
				closeSpeed  : 150,

				closeClick : true,

				helpers : {
					overlay : null
				}
			});

			/*
			 *  Button helper. Disable animations, hide close button, change title type and content
			 */

			jQuery('.fancybox-buttons').fancybox({
				openEffect  : 'none',
				closeEffect : 'none',

				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,

				helpers : {
					title : {
						type : 'inside'
					},
					buttons	: {}
				},

				afterLoad : function() {
					this.title = 'Image ' + (this.index + 1) + ' of ' + this.group.length + (this.title ? ' - ' + this.title : '');
				}
			});


			/*
			 *  Thumbnail helper. Disable animations, hide close button, arrows and slide to next gallery item if clicked
			 */

			jQuery('.fancybox-thumbs').fancybox({
				prevEffect : 'none',
				nextEffect : 'none',

				closeBtn  : false,
				arrows    : false,
				nextClick : true,

				helpers : {
					thumbs : {
						width  : 50,
						height : 50
					}
				}
			});

			/*
			 *  Media helper. Group items, disable animations, hide arrows, enable media and button helpers.
			*/
			jQuery('.fancybox-media')
				.attr('rel', 'media-gallery')
				.fancybox({
					openEffect : 'none',
					closeEffect : 'none',
					prevEffect : 'none',
					nextEffect : 'none',

					arrows : false,
					helpers : {
						media : {},
						buttons : {}
					}
				});

			/*
			 *  Open manually
			 */

			jQuery("#fancybox-manual-a").click(function() {
				$.fancybox.open('1_b.jpg');
			});

			jQuery("#fancybox-manual-b").click(function() {
				$.fancybox.open({
					href : 'iframe.html',
					type : 'iframe',
					padding : 5
				});
			});

			jQuery("#fancybox-manual-c").click(function() {
				$.fancybox.open([
					{
						href : '1_b.jpg',
						title : 'My title'
					}, {
						href : '2_b.jpg',
						title : '2nd title'
					}, {
						href : '3_b.jpg'
					}
				], {
					helpers : {
						thumbs : {
							width: 75,
							height: 50
						}
					}
				});
			});


		});
	</script>
<?php
}

//grid style
function randerGrid($the_query, $gab, $columns, $resultImagesize){
includeFancybox();
  ?>
   <div class="gallery-grid" id="gallery-grid" style="margin-left:-<?php echo $gab ?>px;margin-right:-<?php echo $gab ?>px;">
		<?php
		while ( $the_query->have_posts() ) {
			    $the_query->the_post();
			?>
            <div class="<?php echo 'gallery_inner col'.$columns ?>" style="padding:<?php echo $gab ?>px;">
               <a class="fancybox-buttons" data-fancybox-group="button" href="<?php the_post_thumbnail_url( 'full' )?>">
                   <?php echo get_the_post_thumbnail( get_the_id(),$resultImagesize, true ); ?>
               </a>
		    </div>
			<?php
		}
		?>
		</div>
	<?php
}

//slide style
function randerSlide($the_query, $gab, $columns, $resultImagesize){
includeFancybox();
includeOwlcarousel();
includefontawesome();
  ?>
   <div class="gallery-slide" id="gallery-slide">
		<?php
		while ( $the_query->have_posts() ) {
			    $the_query->the_post();
			?>
            <div class="gallery_inner">
               <a class="fancybox-buttons" data-fancybox-group="button" href="<?php the_post_thumbnail_url( 'full' )?>">
                   <?php echo get_the_post_thumbnail( get_the_id(),$resultImagesize, true ); ?>
               </a>
		    </div>
			<?php
		}
		?>
   </div>
	 <script type="text/javascript">
	 jQuery(document).ready(function() {
	  var owl = jQuery("#gallery-slide");
	  var gab =  <?php echo $gab ?>;
	  var item = <?php echo $columns ?>;
	  owl.owlCarousel({
	      navigation : true,
	      items : item,
		  responsive:{
        0:{
            items:1,
            nav:true
        }, 
        640:{
           items:2, 
           nav:true
        },
        767:{
            items:2,
            nav:true
        },
        1000:{
            items:item,
            nav:true,
        }},
	    margin : gab,
	    nav : true,
		});

	  jQuery('.owl-prev').html('<i class="fa fa-chevron-left" aria-hidden="true"></i>');
	  jQuery('.owl-next').html('<i class="fa fa-chevron-right" aria-hidden="true"></i>');
	});
	</script>
	<?php
}
?>