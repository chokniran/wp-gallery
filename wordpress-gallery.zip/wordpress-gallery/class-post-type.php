<?php
 /***Class Create post type Gallery*/

    add_action( 'init', 'create_post_types_gallery' );
    add_action( 'init', 'create_post_types_photoalbum' );

    // create posttype gallery
    function create_post_types_gallery() {
     register_post_type( 'Photo Gallery',array(            
		  'labels' => array(                
		  	      'name' => __( 'Photo Gallery', 'Wordpress Gallery' ),                
		  	      'singular_name' => __( 'wp-gallery', 'Wordpress Gallery' ),                
		  	      'add_new' => __( 'Add New Photo Gallery', 'Wordpress Gallery' ),                
		  	      'add_new_item' => __( 'Add New Photo Gallery', 'Wordpress Gallery' ),                
		  	      'edit' => __( 'Edit', 'Wordpress Gallery' ),                
		  	      'edit_item' => __( 'Edit Photo Gallery', 'Wordpress Gallery' ),                
		  	      'new_item' => __( 'New Photo Gallery', 'Wordpress Gallery' ),                
		  	      'view' => __( 'View Photo Gallery', 'Wordpress Gallery' ),                
		  	      'view_item' => __( 'View Photo Gallery', 'Wordpress Gallery' ),                
		  	      'search_items' => __( 'Search Photo Gallery', 'Wordpress Gallery' ),                
		  	      'not_found' => __( 'No Photo Gallery', 'Wordpress Gallery' ),                
		  	      'not_found_in_trash' => __( 'No gallery in the Trash', 'Wordpress Gallery' ),),            
		          'hierarchical' => false,'public' => true,            
		                                  'menu_position' => 25,            
		                                  'menu_icon' => plugins_url( 'image/gallery-icon.png' , __FILE__ ),            
		                                  'has_archive' => 'gallery',            
		                                  'rewrite' => array('slug' => 'gallery'),            
		                                  'supports' => array( 'title', 'thumbnail'),            
		                                  'description' => "Create Images Gallery"
           )); 
     }

     // create posttype 
    function create_post_types_photoalbum() {
     register_post_type( 'Photo Album',array(   
          'taxonomy' => array('category', 'post_tag'),         
		  'labels' => array(                
		  	      'name' => __( 'Photo Album', 'Wordpress Gallery' ),                
		  	      'singular_name' => __( 'wp-album', 'Wordpress Gallery' ),                
		  	      'add_new' => __( 'Add New Photo Album', 'Wordpress Gallery' ),                
		  	      'add_new_item' => __( 'Add New Photo Album', 'Wordpress Gallery' ),                
		  	      'edit' => __( 'Edit' ),                
		  	      'edit_item' => __( 'Edit Photo Album', 'Wordpress Gallery' ),                
		  	      'new_item' => __( 'New Photo Album', 'Wordpress Gallery' ),                
		  	      'view' => __( 'View Photo Album', 'Wordpress Gallery' ),                
		  	      'view_item' => __( 'View Photo Album', 'Wordpress Gallery' ),                
		  	      'search_items' => __( 'Search Photo Album', 'Wordpress Gallery' ),                
		  	      'not_found' => __( 'No Photo Album', 'Wordpress Gallery', 'Wordpress Gallery' ),                
		  	      'not_found_in_trash' => __( 'No album in the Trash', 'Wordpress Gallery' ),),            
		          'hierarchical' => false,'public' => true,            
		                                  'menu_position' => 25,            
		                                  'menu_icon' => plugins_url( 'image/album-icon.png' , __FILE__ ),            
		                                  'has_archive' => 'photo-album',            
		                                  'rewrite' => array('slug' => 'photo-album'),            
		                                  'supports' => array( 'title', 'thumbnail'),            
		                                  'description' => "Create photo Album"
           )); 
     }

     // hook into the init action and call create_book_taxonomies when it fires
add_action( 'init', 'create_book_taxonomies', 0 );

// create two taxonomies, genres and writers for the post type "book"
function create_book_taxonomies() {
	// Add new taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Gallery Category', 'taxonomy general name', 'Wordpress Gallery' ),
		'singular_name'     => _x( 'Gallery Category', 'taxonomy singular name', 'Wordpress Gallery' ),
		'search_items'      => __( 'Search Gallery Category', 'Wordpress Gallery' ),
		'all_items'         => __( 'All Gallery Category', 'Wordpress Gallery' ),
		'parent_item'       => __( 'Parent Gallery Category', 'Wordpress Gallery' ),
		'parent_item_colon' => __( 'Parent Gallery Category:', 'Wordpress Gallery' ),
		'edit_item'         => __( 'Edit Gallery Category', 'Wordpress Gallery' ),
		'update_item'       => __( 'Update Gallery Category', 'Wordpress Gallery' ),
		'add_new_item'      => __( 'Add Gallery Category', 'Wordpress Gallery' ),
		'new_item_name'     => __( 'New Gallery Category', 'Wordpress Gallery' ),
		'menu_name'         => __( 'Gallery Category', 'Wordpress Gallery' ),
	);

	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'genre' ),
	);
	register_taxonomy( 'gallery-category', array( 'photogallery' ), $args );
}

add_action( 'add_meta_boxes', 'add_events_metaboxes' );
// Add the Events Meta Boxes

function add_events_metaboxes() {
	add_meta_box('wpt_events_location', 'Select gallery', 'wpt_events_location', 'photoalbum', 'side', 'default');
}
// The Event Location Metabox

function wpt_events_location() {
	global $post;
	
	// Noncename needed to verify where the data originated
	echo '<input type="hidden" name="eventmeta_noncename" id="eventmeta_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	
	// Get the location data if its already been entered
	$location = get_post_meta($post->ID, '_gallery', true);

   
	$terms = get_terms( array(
    'taxonomy' => 'gallery-category',
    'hide_empty' => false,
    ));

	echo '<ul class="main-cat-gallery">';
    foreach ( $terms as $term ) {
        echo '<li><input class="gallery_cat" value="' . $term->name . '" type="checkbox" name="gallery_cat">' . $term->name . '</li>';
    }
    echo '</ul>';
	echo '<input style="background: #efefef;pointer-events: none;" type="text" id="result-cat" name="_gallery" value="' . $location  . '" class="widefat" />';

	?>
       <script type="text/javascript">
      	  jQuery(document).ready(function(){
           jQuery("ul.main-cat-gallery").on("click","li", function(){
           var cat = jQuery(".main-cat-gallery input:checkbox:checked").map(function(){
		      return jQuery(this).val();
		    });

             if(cat.length!=0){
             	for(var i = 0; i< cat.length; i++){
             		var text;
             		if(i=='0'){
                        text = cat[i];
             		}else{
             			text = text+','+ cat[i];
             		}
             	}
             }
             jQuery('#result-cat').val(text);
           });
        });
      </script>
	<?php

}
// Save the Metabox Data

function wpt_save_events_meta($post_id, $post) {
	
	// verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( !wp_verify_nonce( $_POST['eventmeta_noncename'], plugin_basename(__FILE__) )) {
	return $post->ID;
	}

	// Is the user allowed to edit the post or page?
	if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;

	// OK, we're authenticated: we need to find and save the data
	// We'll put it into an array to make it easier to loop though.
	
	$events_meta['_gallery'] = $_POST['_gallery'];
	
	// Add values of $events_meta as custom fields
	
	foreach ($events_meta as $key => $value) { // Cycle through the $events_meta array!
		if( $post->post_type == 'revision' ) return; // Don't store custom data twice
		$value = implode(',', (array)$value); // If $value is an array, make it a CSV (unlikely)
		if(get_post_meta($post->ID, $key, FALSE)) { // If the custom field already has a value
			update_post_meta($post->ID, $key, $value);
		} else { // If the custom field doesn't have a value
			add_post_meta($post->ID, $key, $value);
		}
		if(!$value) delete_post_meta($post->ID, $key); // Delete if blank
	}

}

add_action('save_post', 'wpt_save_events_meta', 1, 2); // save the custom fields


?>