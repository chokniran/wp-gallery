<?php
function viewAlbum( $atts ) {
  	$atts = shortcode_atts( array(
		'category' => '',
		'count' => '',
		'orderby' => '',
		'order' => '',
		'type' => '',
		'imagesize' => '',
		'gab' => '',
		'columns' => '',
	), $atts );

	 //call value Category
    $resultCategory = setValueDefaultCategory($category);

    //call value Count
    $resultCount = setValueDefaultCount($count);

    //call value Orderby
    $resultOrderby = setValueDefaultOrderby($orderby);

    //call value Order
    $resultOrder = setValueDefaultOrder($order);

    //call value Imagesize
    $resultImagesize = setValueDefaultImagesize($imagesize);

    //call value style
    $resultType = setValueDefaultType($type);

    //call value Gab
    $resultGab = setValueDefaultGab($gab);

    //call value Columns
    $resultColumns = setValueDefaultColumns($columns);

	$args = array(
     'post_type' => 'photoalbum',
     'posts_per_page' => 10,
     'order' => 'desc',
     'orderby' => 'date',
   );
	$the_query = new WP_Query( $args );
	?>
     <link rel='stylesheet' href='<?php echo plugins_url( 'css/style.css' , __FILE__ )?>' type='text/css' media='all' />
	<?php 
	  if ( $the_query->have_posts() ) {
			 if($resultType == 'grid'){
                randerAlbumGrid($the_query, $resultGab, $resultColumns, $resultImagesize);
             }else{
            
           }
		}
}
add_shortcode( 'viewAlbum', 'viewAlbum' );

//grid style
function randerAlbumGrid($the_query, $gab, $columns, $resultImagesize){
  ?>
   <div class="gallery-grid" id="gallery-grid" style="margin-left:-<?php echo '10' ?>px;margin-right:-<?php echo '10' ?>px;">
		<?php
		while ( $the_query->have_posts() ) {
			    $the_query->the_post();
			?>
			 <div class="<?php echo 'gallery_inner col'.$columns ?>" style="padding:<?php echo '10' ?>px;">
               <div class="album-cover"><a href="<?php echo get_permalink();?>">
                   <?php echo get_the_post_thumbnail( get_the_id(),$resultImagesize, true ); ?>
               </a></div>
               <h2><a href="<?php echo get_permalink();?>"><?php echo get_the_title()?></a></h2>
		    </div>
			<?php
		}
		?>
		</div>
	<?php
}

function sigleAlbum( $content ) {
	?>  
    <link rel='stylesheet' href='<?php echo plugins_url( 'css/style.css' , __FILE__ )?>' type='text/css' media='all' />
	<?php
    if( is_single() && ! empty( $GLOBALS['post'] ) ) {
        if ( $GLOBALS['post']->ID == get_the_ID() ) {
            if(get_post_type(get_the_ID())=='photoalbum'){
                $cat_name = get_post_meta( get_the_ID(), '_gallery', true );
                $cat_name_arr = explode(",", $cat_name);
                echo '<div class="gallery-grid" id="gallery-grid">';
                echo '<ul class="list-gallery" style="magin-left:-10px;magin-right:-10px">';
                for($i = 0; $i< count($cat_name_arr);$i++){
                	$cat_id_arr = get_term_by('name',$cat_name_arr[$i], 'gallery-category');
                	$cat_gallery_id = $cat_id_arr->term_id;
                	$cat_gallery_slug = $cat_id_arr->slug;
                	$attachment_id   = get_option('categoryimage_'.$cat_gallery_id);
                	$src = wp_get_attachment_image_src($attachment_id, 'style2', true);
                     ?>
                     <li class="gallery_inner col4" style="padding:10px">
                     	<div class="album-cover"><a href="javascript:void(0)" onclick="loadGallery('<?php echo "$cat_gallery_slug" ?>')"><img src="<?php echo $src[0]?>"></a></div>
                     	<h2><a href="javascript:void(0)" onclick="loadGallery('<?php echo "$cat_gallery_slug" ?>')"><?php echo $cat_name_arr[$i] ?></a></h2>
                     </li>
                     <?php
           
                }
                echo '</ul>';
                echo '</div>';
            }

            ?>
              <script type="text/javascript">
              function loadGallery(slug){
              var load = '<div id="floatingCirclesG">'+
							'<div class="f_circleG" id="frotateG_01"></div>'+
							'<div class="f_circleG" id="frotateG_02"></div>'+
							'<div class="f_circleG" id="frotateG_03"></div>'+
							'<div class="f_circleG" id="frotateG_04"></div>'+
							'<div class="f_circleG" id="frotateG_05"></div>'+
							'<div class="f_circleG" id="frotateG_06"></div>'+
							'<div class="f_circleG" id="frotateG_07"></div>'+
							'<div class="f_circleG" id="frotateG_08"></div>'+
						'</div>'
                var url = "<?php echo plugins_url('/get-gallery.php', __FILE__ ); ?>";
                var curUrl = "<?php echo get_permalink(); ?>";
                var catSlug = slug;
                jQuery('.gallery-grid').html(load);
              	jQuery.ajax({
                     url: url,
                     type: "POST",
                     data: { catSlug: catSlug,curUrl: curUrl} ,
                     success: function( data ) {
                      jQuery('.gallery-grid').html(data);
                  }
            })
            }
              </script>
            <?php
        }
    }
    return $content;
}
add_filter('the_content', 'sigleAlbum');
?>