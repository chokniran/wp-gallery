<?php 
require_once('../../../wp-load.php');
$catSlug = $_POST['catSlug'];
$curUrl = $_POST['curUrl'];
echo do_shortcode('[viewGallery type="grid" category="'.$catSlug.'"]');
echo '<div id="row-btn"><a href="'.$curUrl.'" class="btn-back">back</a></div>'
?>