<?php
  /*
Plugin Name: Wordpress Gallery
Plugin URI: Chokniran.io
Description: create your post gallery
Version: 1.0
Author: Chokniran Chongsomchit
Author URI: Chokniran.io
*/

include_once( 'class-post-type.php' );
include_once( 'view-gallery.php' );
include_once( 'view-album.php' );
define('WPCCI_WP_VERSION',      get_bloginfo('version'));
define('WPCCI_WP_MIN_VERSION',  1.0);
define('WPCCI_MIN_PHP_VERSION', '5.3.0');
define('WPCCI_PATH_BASE',       plugin_dir_path(__FILE__));
define('WPCCI_PATH_TEMPLATES',  WPCCI_PATH_BASE . 'templates/');

function wpgallery_textdomain()
{
    load_plugin_textdomain('wpgallery', false, plugin_basename(WPCCI_PATH_BASE) . '/lang/');
}
include_once WPCCI_PATH_BASE . 'helpers.php';
include_once WPCCI_PATH_BASE . 'WPCustomCategoryImage.php';
add_action('init', array('WPCustomCategoryImage', 'initialize'));
add_action('plugins_loaded', 'wpgallery_textdomain');
register_activation_hook(__FILE__, array('WPCustomCategoryImage', 'activate'));
register_deactivation_hook(__FILE__, array('WPCustomCategoryImage', 'deactivate'));
?>